/**
 * Syntax highlighting for Markdown code fences, adapted onto the TUI's palette
 * roles. cli-highlight (highlight.js grammars, pure JS, no WASM) is loaded
 * lazily: the module costs ~150 ms to require, so the TUI kicks the load off
 * at startup and renders plain code until it lands — by which time the first
 * model token has not yet arrived.
 * @module @deepseek-ai/dsh-tui/components/highlight
 */
import type { Palette } from './theme.ts';
/** pi-tui's Markdown hook: highlighted rows for one fenced block. */
export type HighlightCode = (code: string, lang?: string) => string[];
/**
 * Palette-aware code-fence highlighter for pi-tui's `MarkdownTheme.highlightCode`
 * hook. The role table reads the live palette at call time, so an in-place
 * palette swap (color scheme change, `/theme`) recolors without rebuilding.
 */
export interface CodeHighlighter {
    /** The pi-tui Markdown hook. */
    readonly highlightCode: HighlightCode;
    /** Start the lazy module load; safe to call repeatedly. */
    preload(): void;
    /** Drop cached rows so a palette change recolors the next render. */
    invalidate(): void;
    /** Whether any block rendered plain because the module had not landed yet. */
    fallbackUsed(): boolean;
}
/**
 * Build the code highlighter for one palette.
 *
 * @param palette - Live role palette; roles are read per call so later palette
 * mutations recolor subsequent renders without rebuilding this highlighter
 * (call {@link CodeHighlighter.invalidate} to drop rows cached under the old palette).
 * @param enabled - Whether ANSI is emitted at all; `false` never loads the module.
 * @param onReady - One-shot callback once the module lands, when blocks had
 * rendered plain in the meantime — the caller rebuilds the transcript.
 * @returns The highlighter wired into the Markdown theme.
 */
export declare function createCodeHighlighter(palette: Palette, enabled: boolean, onReady?: () => void): CodeHighlighter;
//# sourceMappingURL=highlight.d.ts.map