/**
 * Theme-agnostic ANSI palette and derived pi-tui themes for the terminal front
 * door. The palette is built from the standard 16-color ANSI set plus SGR
 * attributes so every terminal remaps it to its active color scheme.
 * @module @deepseek-ai/dsh-tui/components/theme
 */
import type { MarkdownTheme, SelectListTheme, TerminalColorScheme } from '@earendil-works/pi-tui';
import type { ThemePreset } from './theme-presets.ts';
/**
 * Text carrying exactly one palette color. Branded so the compiler rejects
 * wrapping it in a second color: SGR has no color stack, so an inner span's
 * close reverts to the default foreground rather than the outer color, which
 * silently drops the outer color for the remainder of the line.
 */
export type Colored = string & {
    readonly __coloredBy: unique symbol;
};
/**
 * Text a color may still be applied to: a bare string, or one already carrying
 * SGR attributes. Attributes (bold, italic, underline, strike, reverse) occupy
 * independent SGR groups from the foreground color, so they compose in either
 * order without either side clobbering the other.
 */
export type Colorable = string & {
    readonly __coloredBy?: undefined;
};
/** Applies one color role; rejects input that already carries a color. */
export type ColorRole = (text: Colorable) => Colored;
/** Applies one SGR attribute; accepts colored or uncolored text and preserves its color. */
export type AttributeRole = <T extends string>(text: T) => T;
/**
 * Theme-agnostic role colors and SGR attribute wrappers.
 *
 * One role per visual meaning: `dim` is the single recessed tone, `accent` the
 * single emphasis color, and `success`/`error` double as a diff's added/removed
 * pair. Roles that resolved to the same escape were merged rather than kept as
 * aliases, so a reader cannot pick a name that silently renders as another.
 *
 * Colors and attributes are separately typed: `bold(accent(x))` and
 * `accent(bold(x))` both compile, while `accent(error(x))` does not.
 */
export interface Palette {
    accent: ColorRole;
    /** DeepSeek brand ink; exact gradient callers may override it on truecolor terminals. */
    brand: ColorRole;
    /** The terminal's own default foreground; still a color, so it does not stack. */
    text: ColorRole;
    /** The one recessed tone, below `text`: tool-card bodies, chrome, reasoning, footers. */
    dim: ColorRole;
    success: ColorRole;
    warning: ColorRole;
    error: ColorRole;
    /** Permission prompts and inline code, CC's permission blue (reserved until the permission UI lands). */
    permission: ColorRole;
    /** Plan-mode surfaces, CC's plan teal (reserved until the plan chip lands). */
    plan: ColorRole;
    code: ColorRole;
    bold: AttributeRole;
    italic: AttributeRole;
    underline: AttributeRole;
    strike: AttributeRole;
    /** Reverse video for the active selection; swaps the theme's own fg/bg so it reads on any scheme. */
    selected: AttributeRole;
}
/** Names of the palette's color roles, in the order `/palette` prints them. */
export declare const COLOR_ROLES: readonly ["text", "dim", "accent", "brand", "code", "success", "warning", "error", "permission", "plan"];
/** One color role's name. */
export type ColorRoleName = typeof COLOR_ROLES[number];
/** Names of the palette's attribute roles, in the order `/palette` prints them. */
export declare const ATTRIBUTE_ROLES: readonly ["bold", "italic", "underline", "strike", "selected"];
/** One role's SGR parameters and the reason it carries them. */
export interface RoleSpec {
    /** SGR parameters that open the span, without the `ESC [` prefix or `m` suffix. */
    readonly open: string;
    /** SGR parameters that close it; MUST reset every group `open` sets. */
    readonly close: string;
    /** What the role means, shown by `/palette`. */
    readonly purpose: string;
}
/**
 * Every SGR code the TUI is allowed to emit, keyed by role. This table is the
 * single source: {@link createPalette} derives the wrappers from it and
 * `/palette` prints it, so a role cannot exist in one and not the other, and no
 * component hand-writes an escape.
 *
 * Only the standard 16-color set and SGR attributes appear here. Terminals remap
 * those to the user's active theme, so the TUI stays legible on any background;
 * a fixed 24-bit color would not. The startup gradient and exact official mark
 * color are the two deliberate brand exceptions ({@link gradientText},
 * {@link brandText}).
 *
 * @param scheme - Active terminal color scheme; only `code` differs between them.
 * @returns The SGR spec for every color and attribute role.
 */
export declare function paletteSpec(scheme: TerminalColorScheme): {
    readonly colors: Readonly<Record<typeof COLOR_ROLES[number], RoleSpec>>;
    readonly attributes: Readonly<Record<typeof ATTRIBUTE_ROLES[number], RoleSpec>>;
};
/** Options steering {@link createPalette} toward a named theme preset. */
export interface PaletteOptions {
    /** Named preset overriding color roles; absent keeps the adaptive 16-color spec. */
    preset?: ThemePreset;
    /** Whether 24-bit SGR may be emitted, painting preset roles as `38;2;r;g;b`. */
    truecolor?: boolean;
}
/**
 * Theme-agnostic palette derived from {@link paletteSpec}. Body `text` stays the
 * terminal's default foreground so it reads on light and dark backgrounds alike;
 * grouping uses foreground-only bold, underlined role headers and reverse video
 * rather than fixed background fills or per-line prefixes, so a transcript
 * drag-select copies message text without stray glyphs.
 *
 * @param enabled - Whether ANSI is emitted at all.
 * @param scheme - Active terminal color scheme; adjusts the code role.
 * @param options - Optional named-preset overrides (`/theme`).
 * @returns The role palette for the given scheme.
 */
export declare function createPalette(enabled: boolean, scheme?: TerminalColorScheme, options?: PaletteOptions): Palette;
/**
 * Paint trusted static DeepSeek brand art with the official `#4D6BFE` ink.
 * @param text - Static brand text or raster cells.
 * @returns text wrapped in the official truecolor foreground and a foreground reset.
 */
export declare function brandText(text: string): string;
/**
 * Sample {@link BRAND_GRADIENT} at fraction `t` via piecewise-linear
 * interpolation across its stops.
 *
 * @param t - Position along the gradient; clamped to [0, 1].
 * @returns The interpolated `[r, g, b]` channels, each rounded to 0–255.
 */
export declare function brandColorAt(t: number): readonly [number, number, number];
/**
 * Paint `text` left-to-right in the DeepSeek brand gradient with per-character
 * 24-bit foreground codes, resetting to the default foreground at the end.
 * Foreground-only, so it stays legible on any terminal background; the caller
 * gates it on truecolor support and wraps it in bold.
 *
 * @param text - Text to colorize; sampled once per character.
 * @returns `text` wrapped in truecolor SGR foreground codes.
 */
export declare function gradientText(text: string): string;
/**
 * Derive the pi-tui Markdown theme from a role palette.
 * @param palette - Active role palette.
 * @param highlightCode - Optional syntax highlighter for fenced code blocks;
 * absent renders every code row through the single `codeBlock` role.
 * @returns The Markdown theme wired to palette roles.
 */
export declare function markdownTheme(palette: Palette, highlightCode?: (code: string, lang?: string) => string[]): MarkdownTheme;
/**
 * Derive the pi-tui select-list theme from a role palette.
 * @param palette - Active role palette.
 * @returns The select-list theme wired to palette roles.
 */
export declare function selectTheme(palette: Palette): SelectListTheme;
/**
 * Derive the reverse-video dialog select-list theme from a role palette.
 * @param palette - Active role palette.
 * @returns The dialog select-list theme with a reverse-video selection.
 */
export declare function dialogSelectTheme(palette: Palette): SelectListTheme;
/**
 * Render every palette role as a labelled sample row, each painted by the role
 * it names, so a reader compares the actual tones their terminal produces rather
 * than reading SGR numbers. Colors print first and attributes second because the
 * two groups compose in that order; every row shows its SGR pair so a mismatch
 * between the table and the screen is visible.
 *
 * @param palette - Active role palette, used to paint each sample.
 * @param scheme - Active color scheme, reported in the heading and selecting the spec.
 * @param colorEnabled - Whether ANSI is emitted; reported so an unstyled listing is not confusing.
 * @param options - The same preset options the palette was built with, so the
 * printed SGR pairs match the live roles.
 * @returns The rendered rows, without a trailing blank.
 */
export declare function renderPalette(palette: Palette, scheme: TerminalColorScheme, colorEnabled: boolean, options?: PaletteOptions): string[];
//# sourceMappingURL=theme.d.ts.map