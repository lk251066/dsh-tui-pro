/**
 * Session list component for the assistant's left pane.
 * Displays all active sessions with status, title, cwd, and last activity.
 */
import { Container } from '@earendil-works/pi-tui';
import type { Palette } from '../components/theme.ts';
interface SessionListItem {
    id: string;
    title: string;
    cwd: string;
    status: 'idle' | 'running';
    lastActivityAgo: string;
    isActive: boolean;
}
export declare class SessionListComponent extends Container {
    private readonly palette;
    private items;
    private selectedIndex;
    private readonly maxVisibleItems;
    constructor(palette: Palette, maxHeight: number);
    setItems(items: SessionListItem[]): void;
    getSelectedSessionId(): string | undefined;
    selectNext(): void;
    selectPrevious(): void;
    render(width: number): string[];
}
export {};
//# sourceMappingURL=session-list.d.ts.map