/**
 * pi-tui dialog and selector components for the terminal front door: the status
 * card, prompt-context line, model selector, resume picker, and user-question
 * dialog, plus the model-choice and resume-candidate data they present.
 * @module @deepseek-ai/dsh-tui/components/dialogs
 */
import { type Component, type Focusable } from '@earendil-works/pi-tui';
import type { Context } from '@deepseek-ai/cordis';
import { type Agent, type ModelSelection } from '@deepseek-ai/dsh-agent';
import type { LlmModelReasoningInfo, ReasoningEffortId } from '@deepseek-ai/dsh-llm';
import type { SessionId } from '@deepseek-ai/dsh-session';
import type { SessionRecord } from '@deepseek-ai/dsh-session-query';
import type { AskUserQuestionItem } from '@deepseek-ai/dsh-user-questions';
import { type Palette } from './theme.ts';
import type { ToolCardVisibility } from './transcript.ts';
import { type TuiPromptTemplateToken } from '../prompt.ts';
/** A selectable model advertised by a provider, with its display name, description, and reasoning metadata. */
export interface ModelChoice extends ModelSelection {
    modelName: string;
    description?: string;
    reasoning?: LlmModelReasoningInfo;
}
/**
 * The provider/model route and selected reasoning effort resolved from a model dialog.
 */
export interface ModelDialogSelection {
    choice: ModelChoice;
    reasoningEffort: ReasoningEffortId | undefined;
}
/**
 * Format a provider/model target as its `provider/model` label.
 * @param target - The LLM target.
 * @returns The `provider/model` label.
 */
export declare function targetLabel(target: ModelSelection): string;
/**
 * Format a target compactly as its model name with any selected reasoning effort appended.
 * @param target - The LLM target.
 * @returns The compact `model [effort]` label.
 */
export declare function compactTargetLabel(target: ModelSelection): string;
/**
 * Resolve the display label for a choice's reasoning effort.
 * @param choice - The model choice carrying advertised reasoning metadata.
 * @param effort - The selected effort, or `undefined` for provider default.
 * @returns The effort's display name, `Default`, or `undefined` when the model has no reasoning metadata.
 */
export declare function targetReasoningLabel(choice: ModelChoice, effort: ReasoningEffortId | undefined): string | undefined;
/**
 * Derive the agent's initial LLM target from its logged request header or options.
 * @param agent - The driven agent.
 * @returns The initial target, or `undefined` when unset.
 */
export declare function initialTarget(agent: Agent): ModelSelection | undefined;
/**
 * List every advertised model across registered providers, appending the current
 * target when a provider does not advertise it.
 * @param ctx - Context supplying the LLM service.
 * @param current - The current target, appended when unadvertised.
 * @returns The model choices, flattened across providers.
 */
export declare function readModelChoices(ctx: Context, current: ModelSelection | undefined): Promise<ModelChoice[]>;
/**
 * Format a diagnostic integer with grouping separators.
 * @param value - Integer to format.
 * @returns The grouped decimal string.
 */
export declare function formatDiagnosticNumber(value: number): string;
/**
 * Format a diagnostic timestamp as an ISO date-time in UTC.
 * @param value - Epoch milliseconds.
 * @returns The formatted UTC timestamp.
 */
export declare function formatDiagnosticTime(value: number): string;
/**
 * Format a pluralized count for a diagnostic row.
 * @param value - Count.
 * @param singular - Singular noun; an `s` is appended for other counts.
 * @returns The formatted count.
 */
export declare function formatDiagnosticCount(value: number, singular: string): string;
/**
 * Render a fixed-width filled meter bar for a percentage.
 * @param percent - Percentage in [0, 100].
 * @param palette - Active role palette.
 * @returns The rendered meter.
 */
export declare function diagnosticMeter(percent: number, palette: Palette): string;
/** Options for {@link contextMeter}; none keeps the legacy bar-only rendering. */
export interface ContextMeterOptions {
    /** Append the occupancy percentage beside the bar, colored by the same pressure tier. */
    readonly percent?: boolean;
}
/**
 * Compact 10-cell context-occupancy bar for the prompt row: fill colored by
 * pressure (dim below 60%, warning to 85%, error above), remainder recessed.
 * With `options.percent` the percentage number joins the bar in the same
 * tier color, the way Claude Code's context meter keeps number and bar in one
 * tone; thresholds stay local here (60/85) until the shared module lands.
 */
export declare function contextMeter(percent: number, palette: Palette, options?: ContextMeterOptions): string;
/** One `label: value` row of a status card group. */
export type StatusCardRow = readonly [label: string, value: string];
/** Bordered, grouped field card for one point-in-time status snapshot. */
export declare class StatusCardComponent implements Component {
    private readonly groups;
    private readonly palette;
    constructor(groups: readonly (readonly StatusCardRow[])[], palette: Palette);
    invalidate(): void;
    render(width: number): string[];
}
/** The left/right template line rendered above the editor. */
export declare class PromptContextComponent implements Component {
    private readonly leftTemplate;
    private readonly rightTemplate;
    private readonly resolve;
    constructor(leftTemplate: readonly TuiPromptTemplateToken[], rightTemplate: readonly TuiPromptTemplateToken[], resolve: (name: string) => string | undefined);
    invalidate(): void;
    render(width: number): string[];
}
/** A user's answer to one question: chosen option labels and an optional custom answer. */
export interface QuestionSelection {
    selected: string[];
    custom?: string;
}
/** Frame shape {@link renderDialog} draws around a dialog body. */
export interface RenderDialogOptions {
    /**
     * `round` (the default) draws the full rounded border for strong-interruption
     * dialogs — approvals, confirmations, pickers. `topline` draws Claude Code's
     * browse-pane form instead: a bold title over one full-width accent rule,
     * content padded two columns, and no surrounding border.
     */
    readonly frame?: 'round' | 'topline';
}
/**
 * Render a dialog frame around body lines: by default a rounded border with a
 * titled top edge, or — with `options.frame: 'topline'` — Claude Code's
 * browse-pane form of a bold title over one full-width accent rule.
 * @param title - Dialog title shown in the frame.
 * @param body - Body lines.
 * @param width - Dialog width in columns.
 * @param palette - Active role palette.
 * @param options - Frame selection; defaults to the rounded border.
 * @returns The framed dialog lines.
 */
export declare function renderDialog(title: string, body: readonly string[], width: number, palette: Palette, options?: RenderDialogOptions): string[];
/** Keyboard model selector rendered as a bordered overlay, with a filter box and per-model reasoning-effort cycling. */
export declare class ModelDialog implements Component {
    private readonly maxVisible;
    private readonly palette;
    private readonly done;
    private readonly cancel;
    /** F5 re-reads the catalog through this hook and rebuilds the list. */
    private readonly onRefresh?;
    private list;
    private readonly filter;
    private readonly items;
    private readonly choices;
    private readonly efforts;
    private readonly currentValue;
    /** The route the dialog opened with; a refresh rebuilds against it. */
    private readonly selection;
    /** True while an F5 catalog refresh is in flight. */
    private refreshing;
    constructor(choices: readonly ModelChoice[], current: ModelSelection | undefined, maxVisible: number, palette: Palette, done: (selection: ModelDialogSelection) => void, cancel: () => void, 
    /** F5 re-reads the catalog through this hook and rebuilds the list. */
    onRefresh?: (() => Promise<readonly ModelChoice[]>) | undefined);
    /** (Re)build the item/choice/effort tables from a catalog snapshot. */
    private rebuildItems;
    /** Build a SelectList over the currently filtered items, selecting `selectValue` when present. */
    private buildList;
    /** Items matching the filter box, as a case-insensitive substring over the label, model name, and description. */
    private filteredItems;
    private confirm;
    private describeChoice;
    private cycleReasoningEffort;
    invalidate(): void;
    handleInput(data: string): void;
    render(width: number): string[];
}
/** Both transcript-detail dimensions, applied immediately on each Tab. */
export interface DetailsSelection {
    readonly visibility: ToolCardVisibility;
    readonly showReasoning: boolean;
}
/**
 * Keyboard toggle over the two transcript-detail entries — tool-card
 * visibility and reasoning display. Tab cycles the highlighted entry's value
 * and applies it immediately, so the transcript behind the dialog is the live
 * preview; Enter, Esc, or Ctrl+C closes.
 */
export declare class DetailsDialog implements Component {
    private visibility;
    private showReasoning;
    private readonly palette;
    private readonly apply;
    private readonly close;
    private readonly list;
    private readonly toolsItem;
    private readonly reasoningItem;
    constructor(visibility: ToolCardVisibility, showReasoning: boolean, palette: Palette, apply: (selection: DetailsSelection) => void, close: () => void);
    private reasoningLabel;
    /** Cycle the highlighted entry one step and apply the new state. */
    private cycle;
    invalidate(): void;
    handleInput(data: string): void;
    render(width: number): string[];
}
/** One `/sessions` picker row: one live in-process session. */
export interface SessionChoice {
    /** The session the row switches to when chosen. */
    sessionId: SessionId;
    /** Row label: the session's title, or its id when untitled. */
    label: string;
    /** Secondary detail: the id when titled, plus agent status and turn count. */
    detail: string;
    /** Whether this row is the currently mounted session. */
    active: boolean;
}
/**
 * Keyboard switcher over the live in-process sessions: ↑/↓ move, Enter or a
 * digit 1-9 picks a rendered row and switches the mounted channel, Esc or
 * Ctrl+C closes without switching. The active row stays selectable but a
 * no-op (the requested state already holds).
 */
export declare class SessionPickerDialog implements Component {
    private readonly choices;
    private readonly palette;
    private readonly choose;
    private readonly close;
    private selectedIndex;
    constructor(choices: readonly SessionChoice[], palette: Palette, choose: (choice: SessionChoice) => void, close: () => void);
    invalidate(): void;
    handleInput(data: string): void;
    render(width: number): string[];
}
/** One `/memories` browser row: one durable memory, host-formatted. */
export interface MemoryRowView {
    /** Opaque id handed back to the remove callback. */
    readonly id: string;
    /** Row body: the memory's text. */
    readonly label: string;
    /** Secondary detail: tags and the updated date. */
    readonly detail: string;
}
/**
 * Keyboard browser over the durable memory store: ↑/↓ move (wrapping),
 * `d` deletes the highlighted row through the remove callback and re-reads
 * the store, `r` re-reads without deleting, Esc or Ctrl+C closes. Deletion is
 * direct — a memory is a one-line fact, not a file.
 */
export declare class MemoryBrowserDialog implements Component {
    private readonly palette;
    private readonly remove;
    private readonly close;
    private readonly refresh;
    private rows;
    private selectedIndex;
    constructor(rows: readonly MemoryRowView[], palette: Palette, remove: (id: string) => Promise<boolean>, close: () => void, refresh: () => readonly MemoryRowView[]);
    invalidate(): void;
    handleInput(data: string): void;
    /** Keep the highlight on a real row after the store shrank. */
    private clampSelection;
    render(width: number): string[];
}
/** One `/theme` picker row. */
export interface ThemeChoice {
    name: string;
    description: string;
    dark: boolean;
}
/**
 * A read-only browse dialog over pre-rendered lines, framed by a bold title
 * over one full-width rule (Claude Code's pane form): Esc/Ctrl+C/q closes,
 * `r` recomputes the body through {@link refresh} when supplied. Backs
 * `/context`, `/agents`, `/jobs`, and `/settings`.
 */
export declare class StaticDialog implements Component {
    private readonly title;
    private readonly palette;
    private readonly close;
    private readonly refresh?;
    private lines;
    constructor(title: string, lines: readonly string[], palette: Palette, close: () => void, refresh?: (() => readonly string[]) | undefined);
    invalidate(): void;
    handleInput(data: string): void;
    render(width: number): string[];
}
/**
 * The `/rename` sheet: a single-line title editor. Enter renames (empty input
 * rejects with the sheet's own error line), Esc/Ctrl+C closes unchanged.
 */
export declare class RenameDialog implements Component {
    private readonly palette;
    private readonly submit;
    private readonly close;
    private readonly input;
    private error;
    constructor(initial: string, palette: Palette, submit: (title: string) => void, close: () => void);
    invalidate(): void;
    handleInput(data: string): void;
    render(width: number): string[];
}
/**
 * A two-option confirmation (No / Yes) for risky actions — the
 * danger-permission acknowledgement, mirroring Claude Code's bypass-permissions
 * dialog: the safe `No` item is FIRST and focused at open, so Enter alone never
 * accepts the risk. A `\n`-separated message renders its first line as an
 * error-colored warning title and the rest as the warning body. Esc and Ctrl+C
 * cancel.
 */
export declare class ConfirmDialog implements Component {
    private readonly title;
    private readonly message;
    private readonly palette;
    private readonly choose;
    private readonly close;
    private readonly list;
    constructor(title: string, message: string, palette: Palette, choose: (confirmed: boolean) => void, close: () => void, 
    /** Item focused at open: 0 is the safe `No` item (the default), 1 the risky `Yes` item. */
    defaultIndex?: number);
    invalidate(): void;
    handleInput(data: string): void;
    render(width: number): string[];
}
/** The approval dialog's answer vocabulary (a session grant covers one tool for the TUI's lifetime). */
export type ApprovalChoice = 'allow-once' | 'allow-session' | 'reject';
/**
 * The tool-approval prompt: a Claude-Code-style takeover above the editor while
 * a tool call waits on the user's decision. Options carry dim `N.` prefixes and
 * digit keys 1-9 pick them directly; Enter picks the highlighted option; Esc
 * and Ctrl+C reject (the turn keeps running so the model sees the denial).
 * Tab opens the footnote line — an optional instruction submitted alongside the
 * highlighted option; an empty submit passes the option through unchanged, the
 * way Claude Code's "tell Claude what to do differently" does.
 */
export declare class ApprovalDialog implements Component {
    private readonly reason;
    private readonly palette;
    private readonly choose;
    private readonly close;
    private readonly list;
    private readonly headline;
    /** Answer values in list order, addressed by the 1-9 digit keys. */
    private readonly choices;
    private readonly input;
    private mode;
    constructor(toolName: string, reason: string | undefined, callSummary: string | undefined, palette: Palette, choose: (choice: ApprovalChoice, feedback?: string) => void, close: () => void);
    invalidate(): void;
    handleInput(data: string): void;
    render(width: number): string[];
}
/**
 * The `/theme` picker: a top-rule pane over the shipped presets. Tab
 * applies the highlighted theme immediately as a live preview behind the
 * dialog; Enter keeps it and closes; Esc/Ctrl+C restores the entry theme.
 */
export declare class ThemeDialog implements Component {
    private readonly palette;
    private readonly apply;
    private readonly close;
    private readonly list;
    private readonly entry;
    constructor(choices: readonly ThemeChoice[], current: string, palette: Palette, apply: (name: string) => void, close: () => void);
    /** Re-apply the theme active when the dialog opened, then close. */
    private restore;
    invalidate(): void;
    handleInput(data: string): void;
    render(width: number): string[];
}
/** A resume selector row summarizing one session from metadata and its folded title. */
export interface ResumeCandidate {
    record: SessionRecord;
    title: string;
    /** Last observed change: live last-event time or artifact mtime, falling back to creation. */
    lastActivityAt: number;
    /** Whether the session's workspace is the one the current session runs in, which selects the picker scope that lists it. */
    currentWorkspace: boolean;
    /** The session's own workspace as a prompt-style label; the all-workspaces scope shows it per row. */
    workspaceLabel: string;
    disabledReason?: string;
}
/**
 * Build one resume selector row from a record, its batch-folded title, and a
 * metadata-derived activity time, deriving the workspace scope and any reason
 * the session cannot be resumed here. A workspace other than the current one
 * is a scope, not a disabled reason: resuming it hands the process off into
 * that directory. Rows carry no per-log detail beyond the title — route and
 * replay validity are checked by the Enter-time preflight against the one
 * chosen log.
 * @param record - The session record.
 * @param title - The session's batch-folded title, absent for an untitled log.
 * @param lastActivityAt - Metadata activity time; absent falls back to the header's creation time.
 * @param currentId - The current session id.
 * @param cwd - The CURRENT session's workspace, which decides the picker scope this row falls in.
 * @param formatWorkspace - Renders THIS record's own cwd as its prompt-style label.
 * @returns The summarized resume candidate.
 */
export declare function summarizeResumeCandidate(record: SessionRecord, title: string | undefined, lastActivityAt: number | undefined, currentId: SessionId, cwd: string | undefined, formatWorkspace: (cwd: string | undefined) => string): ResumeCandidate;
/** Which workspaces the resume picker currently lists. */
export type ResumeScope = 'workspace' | 'all';
/**
 * Full-viewport keyboard selector over detached, preflighted resume summaries.
 *
 * Two scopes over one candidate set: `workspace` (the default) lists only the
 * current session's workspace, `all` lists every workspace and labels each row
 * with its own. Tab toggles between them; the search query and selection reset
 * on a scope change so the highlighted row always belongs to the visible list.
 *
 * The picker opens before the session scan settles: an `undefined` candidate
 * set renders a loading placeholder that keeps input away from the editor,
 * and `setCandidates` swaps the scanned rows in without replacing the overlay.
 */
export declare class ResumePicker implements Component, Focusable {
    private readonly maxVisible;
    private readonly workspaceLabel;
    private readonly viewportRows;
    private readonly palette;
    private readonly done;
    private readonly cancel;
    private readonly search;
    private pasteBuffer;
    private selectedIndex;
    private error;
    private scope;
    private candidates;
    focused: boolean;
    constructor(candidates: readonly ResumeCandidate[] | undefined, maxVisible: number, workspaceLabel: string, viewportRows: () => number, palette: Palette, done: (candidate: ResumeCandidate) => void, cancel: () => void);
    invalidate(): void;
    /**
     * Replace the loading placeholder with the scanned candidate set.
     * @param candidates - the summarized rows the finished scan produced.
     */
    setCandidates(candidates: readonly ResumeCandidate[]): void;
    /** Candidates in the active scope, before the search query narrows them. */
    private scoped;
    private filtered;
    private visibleCandidateCount;
    private handleBracketedPaste;
    handleInput(data: string): void;
    /**
     * The scope line under the search box: the active scope with the current
     * workspace it means, and the inactive scope with the count Tab would reveal.
     */
    private renderScopeLine;
    render(width: number): string[];
}
/** Inline dialog for one user question with option or custom-answer modes. */
export declare class QuestionDialog implements Component, Focusable {
    private readonly question;
    private readonly position;
    private readonly total;
    private readonly unanswered;
    private readonly maxVisible;
    private readonly maxHeight;
    private readonly palette;
    private readonly done;
    private readonly cancel;
    private selectedIndex;
    private selected;
    private headerPage;
    private selectedBlockPage;
    /**
     * The option index window the last render showed, `[start, end)`. Digit keys
     * 1-9 address the RENDERED `N.` numbers — absolute option indices — and only
     * inside this window; until a first render narrows it, all options count as
     * visible.
     */
    private visibleRange;
    private mode;
    private error;
    private readonly input;
    private readonly options;
    focused: boolean;
    constructor(question: AskUserQuestionItem, position: number, total: number, unanswered: number, maxVisible: number, maxHeight: () => number, palette: Palette, done: (selection: QuestionSelection) => void, cancel: () => void);
    invalidate(): void;
    handleInput(data: string): void;
    /** Submit the options-mode selection (Enter, and digit direct-select on single-select questions). */
    private submitOptions;
    /**
     * Apply a 1-9 direct-select key to the option rendered with that number:
     * single-select confirms the option (move + Enter in one key), multi-select
     * toggles its checkmark. A number outside the rendered window is ignored.
     */
    private selectByDigit;
    private submitCustom;
    private selectedOptionLabels;
    /** Page backward through an oversized option, then through question detail. */
    private pageBackward;
    /** Page forward through question detail, then through an oversized option. */
    private pageForward;
    render(width: number): string[];
    /** Render one option as wrapped label and indented description lines. */
    private renderOptionBlock;
    /** Keep the question visible when fixed chrome must be compacted. */
    private compactQuestionHeader;
    /** Keep Page Up / Page Down discoverable when a full pager status cannot fit. */
    private pagerStatus;
    /** Render custom-mode controls on one row when the header must compact. */
    private compactCustomControls;
    /** Render a one-row option footer that retains every mode-specific control. */
    private compactOptionControls;
    /**
     * Choose option blocks that fit while keeping the selected option visible.
     * Omitted blocks are counted at each end for explicit overflow markers.
     */
    private windowBlocks;
}
//# sourceMappingURL=dialogs.d.ts.map