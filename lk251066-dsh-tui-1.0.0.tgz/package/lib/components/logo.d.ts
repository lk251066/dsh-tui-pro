/**
 * The startup logo: "DEEPSEEK HARNESS" as five-row block letters (the
 * dsh-cc-tui convention), painted column-by-column through the brand
 * indigo→ice-blue gradient with an optional shimmer highlight that sweeps
 * across after the banner settles. Narrow terminals drop to the DEEPSEEK word
 * alone, then to plain text (handled by the header, not here).
 * @module @deepseek-ai/dsh-tui/components/logo
 */
import { type Palette } from './theme.ts';
/** Columns one word's letters occupy. */
export declare function logoWordWidth(word: string): number;
/** Columns the full two-word logo occupies. */
export declare function logoFullWidth(): number;
/** Columns the DEEPSEEK word alone occupies. */
export declare function logoSingleWordWidth(): number;
/** The unpainted full-logo rows (both words). */
export declare function fullLogoRows(): string[];
/** The unpainted DEEPSEEK-word rows. */
export declare function singleWordLogoRows(): string[];
/** Columns the shimmer highlight spans. */
export declare const SHIMMER_WIDTH = 12;
/** Milliseconds per shimmer animation step (columns advance 2 per step). */
export declare const SHIMMER_INTERVAL_MS = 45;
/**
 * Paint one block-letter row: each filled column samples the brand gradient
 * at its position; a shimmer window (when active) blends covered columns
 * toward ice white with a soft edge fade. Without truecolor the row takes a
 * single accent tone and the shimmer brightens with bold.
 * @param row - One unpainted block-letter row from {@link fullLogoRows}.
 * @param palette - Active role palette for the non-truecolor fallback.
 * @param gradient - Whether 24-bit color is on.
 * @param shimmerOffset - Left edge of the shimmer window, or `undefined` off.
 * @returns The styled row.
 */
export declare function paintLogoRow(row: string, palette: Palette, gradient: boolean, shimmerOffset: number | undefined): string;
//# sourceMappingURL=logo.d.ts.map