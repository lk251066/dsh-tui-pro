/**
 * pi-tui transcript components: the startup banner, user/assistant messages,
 * the streaming assistant buffer, tool cards, and the todo panel. Each is a
 * pure function of its inputs and the active palette.
 * @module @deepseek-ai/dsh-tui/components/transcript
 */
import { Container, type Component, type MarkdownTheme } from '@earendil-works/pi-tui';
import type { ContentBlock, StreamChunk } from '@deepseek-ai/dsh-llm';
import type { SessionEvent, TodoItem } from '@deepseek-ai/dsh-session';
import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
import type { FileDiff } from '@deepseek-ai/dsh-tools';
import { type Palette } from './theme.ts';
import { type ParsedArguments } from './content.ts';
import { type StepPosition } from '../chat/timing.ts';
interface RenderedDiff {
    lines: string[];
    added: number;
    removed: number;
    approximate: boolean;
}
/** Context rows kept at each edge of a long unchanged run before its middle folds. */
export declare const DIFF_CONTEXT_LINES = 3;
/** Total diff rows one file may render before the middle folds away. */
export declare const DIFF_MAX_RENDER_LINES = 60;
/** pi-tui's code-fence hook shape, which {@link renderDiff} reuses for diff rows. */
export type DiffHighlight = (code: string, lang?: string) => string[];
/**
 * A file diff rendered as terminal rows in the Claude Code shape: a dim
 * line-number gutter (new-side numbers for added and context rows, old-side
 * for removed), syntax-highlighted row content when a highlighter is
 * available, long unchanged runs and oversized diffs folded to dim `⋯` notes,
 * and unchanged context that stays neutral and does not affect exact change
 * totals. Comparisons beyond the edit-distance budget fall back to whole-side
 * rendering so a model-authored pending edit cannot stall the TUI.
 */
export declare function renderDiff(diff: FileDiff, maxDiffEditLength: number, palette: Palette, skipPathHeader?: boolean, highlight?: DiffHighlight): RenderedDiff;
/**
 * Identity segments of the condensed one-line header: the product version,
 * the active model label, the working directory, and the session title when
 * one is set. An empty `model`/`version` omits that segment from the line.
 */
export interface CondensedHeaderInfo {
    /** Package version rendered as `v{version}`. */
    readonly version: string;
    /** Active model label (empty omits the segment). */
    readonly model: string;
    /** Formatted working-directory label (empty omits the segment). */
    readonly cwd: string;
    /** Session title appended as `— {title}`; `undefined`/empty omits it. */
    readonly title: string | undefined;
}
/**
 * The startup banner. A fresh (history-less) session gets the full banner:
 * the block-letter DEEPSEEK HARNESS logo painted through the brand gradient
 * (plus a welcome row and a shortcut tips row); mid-width drops to the
 * DEEPSEEK word alone; narrow falls back to one compact text line. The sweep
 * reveal and the shimmer pass clip/overlay whichever shape is on screen.
 *
 * A session that already carries conversation (Claude Code's CondensedLogo
 * convention) drops the five-row logo for one identity row instead — accent
 * `dsh`, the product name, the version, the model, the cwd, and the session
 * title — static, with no reveal or shimmer animation. Narrow terminals keep
 * the plain text fallback either way.
 */
export declare class HeaderComponent implements Component {
    private readonly subtitle;
    private readonly palette;
    private readonly gradient;
    /**
     * Condensed identity segments, read per render; `undefined` renders the
     * full startup banner instead.
     */
    private readonly condensedInfo;
    /** Columns of the banner currently revealed; `undefined` renders it whole. */
    private revealWidth;
    /** Left edge of the shimmer window over the logo; `undefined` = off. */
    private shimmerOffset;
    constructor(subtitle: () => string | undefined, palette: Palette, gradient: boolean, 
    /**
     * Condensed identity segments, read per render; `undefined` renders the
     * full startup banner instead.
     */
    condensedInfo?: () => CondensedHeaderInfo | undefined);
    /**
     * Clip the banner to `width` columns (the sweep reveal); `undefined` restores it.
     * @param width - Revealed banner width in columns, or `undefined` for the whole banner.
     */
    setRevealWidth(width: number | undefined): void;
    /**
     * Park the shimmer highlight at `offset` columns (or clear it).
     * @param offset - Left edge of the highlight window, or `undefined` to clear.
     */
    setShimmerOffset(offset: number | undefined): void;
    invalidate(): void;
    render(width: number): string[];
    /**
     * The condensed identity row: `dsh DEEPSEEK HARNESS v{version} · {model}
     * {cwd} — {title}` on one line — bold name, dim metadata, the title last.
     * Static by design: no reveal clip and no shimmer, whichever animation
     * timers happen to run.
     */
    private renderCondensed;
    /** Block-letter logo rows plus the welcome and tips rows, reveal-clipped. */
    private renderLogo;
    /** Narrow fallback: the one-line text banner. */
    private renderText;
}
/**
 * One image content block, rendered through pi-tui's `Image` once the
 * attachment bytes land (kitty/iTerm2 protocols; other terminals get the
 * component's own fallback line). Until then a placeholder line shows.
 */
export declare class ImageBlockComponent extends Container {
    constructor(attachmentId: string, mediaType: string, load: (attachmentId: string) => Promise<Uint8Array | undefined>, palette: Palette);
    invalidate(): void;
}
/**
 * A user or steering prompt in the transcript. Every body line carries the
 * Claude Code `>` quote marker in the accent color and the text renders as
 * plain echo (no markdown styling, the way Claude Code quotes input back), so
 * a terminal drag-select copies the prompt verbatim. Image blocks render
 * inline beneath the text through {@link ImageBlockComponent}.
 */
export declare class UserMessageComponent extends Container {
    constructor(text: string, palette: Palette, images?: readonly {
        attachmentId: string;
        mediaType: string;
    }[], loadImage?: (attachmentId: string) => Promise<Uint8Array | undefined>);
}
/** A live assistant step: streamed reasoning/text blocks until the message settles. */
export declare class StreamingAssistantComponent extends Container {
    /** The step's turn/step coordinates, used to group steps into its turn. */
    readonly position: StepPosition;
    private showReasoning;
    private readonly palette;
    private readonly mdTheme;
    private readonly blocks;
    private settledContent;
    private foldedContinuation;
    private startedAt;
    private thinkingMs;
    constructor(
    /** The step's turn/step coordinates, used to group steps into its turn. */
    position: StepPosition, showReasoning: boolean, palette: Palette, mdTheme: MarkdownTheme);
    /**
     * Record the step's start time (its `step/start` event time) for the
     * collapsed thinking line's duration.
     * @param time - Step start in epoch milliseconds, or `undefined` when the
     * opening event is unavailable (the duration is simply omitted).
     */
    markStart(time: number | undefined): void;
    /**
     * Replace the streamed blocks with the step's settled content.
     * @param content - The settled assistant content blocks.
     * @param at - Settle time in epoch milliseconds (the `assistant/message`
     * event time) for the collapsed thinking duration; omitted leaves it unset.
     */
    settle(content: readonly ContentBlock[], at?: number): void;
    /**
     * Whether this step's assistant message has settled.
     * @returns `true` once {@link settle} has run.
     */
    isSettled(): boolean;
    invalidate(): void;
    /**
     * Fold one streamed chunk into the live block buffer and re-render.
     * @param chunk - The streamed assistant chunk.
     */
    update(chunk: StreamChunk): void;
    /**
     * Toggle whether reasoning blocks render, then re-render.
     * @param show - Whether to show reasoning blocks.
     */
    setShowReasoning(show: boolean): void;
    /**
     * Mark this step as a folded continuation of its turn: no `Assistant` header,
     * and no output at all while the step has no visible body. Used while tool
     * cards are hidden so a turn reads as one assistant message.
     * @param folded - Whether to render as a headerless continuation.
     */
    setFoldedContinuation(folded: boolean): void;
    /**
     * Whether the step currently renders visible reasoning or text.
     * @returns `true` when a header-owning render would show a body.
     */
    hasVisibleBody(): boolean;
    /** The settled content when available, otherwise the streamed blocks in model order. */
    private presentedContent;
    private rebuild;
}
/**
 * Ctrl+O card-visibility cycle: `hidden` drops tool cards from the transcript,
 * `collapsed` previews the first body lines, `expanded` shows everything.
 */
export type ToolCardVisibility = 'hidden' | 'collapsed' | 'expanded';
/**
 * Transcript card with a width-keyed rendered-row cache. pi-tui re-renders
 * every component each frame and relies on per-component line caches (its own
 * `Text`/`Markdown` do this); a card that rebuilds rows inside `render(width)`
 * would re-wrap its output every frame
 * ([rationale](../../../../../.agents/notes/implemented/bug-fix/2026-08-03-tui-long-session-render-costs.md)).
 * Subclasses render through {@link renderLines} and call {@link dropLines}
 * from every state mutator; with `invalidate()` (pi-tui's tree-wide cascade)
 * also dropping, a state change always re-renders.
 */
declare abstract class CachedCardComponent implements Component {
    private cached;
    /** Discard the cached rows so the next render recomputes them. */
    protected dropLines(): void;
    invalidate(): void;
    render(width: number): string[];
    /**
     * Render the card's rows for `width` without caching.
     * @param width - Render width the rows are wrapped to.
     * @returns The card's rows.
     */
    protected abstract renderLines(width: number): string[];
}
/** A tool call and its result, rendered as a collapsible status card. */
export declare class ToolCardComponent extends CachedCardComponent {
    private readonly name;
    private readonly parsed;
    private readonly definition;
    private readonly maxOutputLines;
    private readonly maxDiffEditLength;
    private readonly palette;
    private readonly mdTheme;
    /** Wall-clock time of the `tool/call` event, for the settled duration. */
    private readonly startedAt?;
    private result;
    private visibility;
    private callView;
    private resultView;
    private diffBodyCache;
    private endedAt;
    private spinnerFrame;
    constructor(name: string, parsed: ParsedArguments, definition: ToolDefinition | undefined, maxOutputLines: number, maxDiffEditLength: number, palette: Palette, mdTheme: MarkdownTheme, 
    /** Wall-clock time of the `tool/call` event, for the settled duration. */
    startedAt?: number | undefined);
    /** Whether the call is still awaiting its result. */
    isPending(): boolean;
    /** The call's registered tool name, for grouping and group summaries. */
    get toolName(): string;
    /**
     * The card's current verb label (progressive while pending, settled after),
     * for surfaces that name the call outside the transcript (approval dialogs).
     */
    label(): string;
    /**
     * Show `frame` in place of the pending glyph (the braille spinner); one
     * frame per animation tick while the newest pending card animates.
     * @param frame - The spinner frame glyph, or `undefined` for the hollow dot.
     */
    setSpinner(frame: string | undefined): void;
    private presentCall;
    /**
     * Record the tool result and derive its result view.
     * @param event - The `tool/result` event payload.
     * @param endedAt - Wall-clock time of the `tool/result` event.
     */
    updateResult(event: Extract<SessionEvent, {
        type: 'tool/result';
    }>['data'], endedAt?: number): void;
    /**
     * Set the card's visibility state.
     * @param visibility - Hidden, collapsed preview, or full body.
     */
    setVisibility(visibility: ToolCardVisibility): void;
    protected renderLines(width: number): string[];
    /** The pending terminal call view, when this row is a terminal card. */
    private terminalPending;
    /**
     * The settled label's view: the result view with its omitted fields falling
     * back to the call view's (a result view that replaces no title keeps the
     * pending one — e.g. a terminal result carries the output but not the
     * command, which lives in the call view's title).
     */
    private mergedView;
    private renderBody;
    /**
     * A tool's own output text as dim rows — the card's result-output color, which
     * separates what the tool produced from the card's own framing. A blank row
     * stays the empty string so the terminal branch's blank-row filter still reads
     * it as blank instead of as an ANSI-wrapped value.
     */
    private dimOutput;
    /**
     * Render a generic card's prelude and result as one Markdown document under the
     * dim body tone. Rendering both together preserves the document's own block
     * spacing (Markdown's blank row before a heading); dimming every row keeps the
     * card body one uniform tone, so only the status-colored header carries color.
     */
    private dimBody;
}
/**
 * A run of adjacent low-signal tool calls (reads, searches, listings)
 * collapsed into one Claude-Code-style summary row — `⏺ Read 12 files ·
 * searched 3 patterns · listed 2 dirs (ctrl+o to expand)`, one dim row with
 * bold counts where twenty full cards used to stand. The member cards are
 * reused, so results keep flowing into the same objects: `collapsed` renders
 * only the summary (its glyph tracks the newest pending member, with that
 * call's label as the activity hint), `expanded` lists each member's own rows
 * beneath the summary (through the members' per-card width caches), and
 * `hidden` drops the row together with the cards.
 */
export declare class CollapsedToolGroupComponent extends CachedCardComponent {
    private readonly palette;
    private visibility;
    private spinnerFrame;
    private readonly members;
    constructor(cards: readonly ToolCardComponent[], palette: Palette);
    /** The member cards, in arrival order. */
    get cards(): readonly ToolCardComponent[];
    /**
     * Add one more adjacent member call and re-render the summary.
     * @param card - The later foldable call's card, already registered with the
     * visibility cycle and result map by the assembly layer.
     */
    add(card: ToolCardComponent): void;
    /** The newest member still awaiting its result, when the run is mid-flight. */
    private pendingCard;
    /**
     * Show `frame` in place of the pending glyph (the braille spinner) while any
     * member pends; a fully settled group ignores it.
     * @param frame - The spinner frame glyph, or `undefined` for the hollow dot.
     */
    setSpinner(frame: string | undefined): void;
    /**
     * Drop cached rows after a member card mutated outside this component — a
     * result landing (settled glyph, counts) or any other state the summary reads.
     */
    refresh(): void;
    /**
     * Set the group's visibility state.
     * @param visibility - Hidden (nothing at all), collapsed summary row, or the
     * expanded list of member cards.
     */
    setVisibility(visibility: ToolCardVisibility): void;
    /**
     * The summary segments in display order: the three fixed categories
     * (`files`, `patterns`, `dirs`), then per-tool-name counts for foldable
     * names with no category. Each carries the wording split around its count so
     * the row can bold the number while the prose stays dim.
     */
    private segments;
    /**
     * The summary row through the palette: dim prose and glyph, bold counts, the
     * pieces concatenated (SGR has no color stack, so spans never nest).
     * @param glyph - The state glyph (pending spinner frame or settled dot).
     */
    private summaryRow;
    protected renderLines(width: number): string[];
}
/**
 * Injected context (plugin/goal source, e.g. `workspace-context`), rendered as a
 * collapsible dim card that shares the tool-card `Ctrl+O` toggle. The header is
 * `Context · <label>`; the body is the message text as dim prose, one tone with
 * the header and the fold marker, folded to `maxOutputLines`, with a surrounding
 * reminder frame stripped because the source label already names the context.
 *
 * Injected context is prose, not markup, so this card does not parse it. The
 * `<system-reminder>` frame is a prompting convention no model is trained on
 * ([envelope rationale](../../../../../.agents/notes/implemented/simplification/2026-07-20-unwrap-injected-content-envelopes.md)),
 * and instruction bodies legitimately contain a raw `&` or angle-bracket
 * placeholders (`packages/<group>/<pkg>/`, `-t <name>`) that are prose rather than
 * elements. Tree-rendering such a payload depended on whether it happened to be
 * well-formed XML, which made both the fold and the frame-line suppression
 * content-dependent.
 */
export declare class ContextCardComponent extends CachedCardComponent {
    private readonly label;
    private readonly text;
    private readonly maxOutputLines;
    private readonly palette;
    private expanded;
    constructor(label: string, text: string, maxOutputLines: number, palette: Palette);
    /**
     * Expand or collapse the card body.
     * @param expanded - Whether the full body is shown.
     */
    setExpanded(expanded: boolean): void;
    protected renderLines(width: number): string[];
}
/** The plan/todo panel rendered above the prompt. */
export declare class TodoComponent implements Component {
    private readonly palette;
    private todos;
    constructor(palette: Palette);
    /**
     * Replace the rendered plan items.
     * @param todos - The current todo items.
     */
    update(todos: readonly TodoItem[]): void;
    invalidate(): void;
    render(width: number): string[];
}
export {};
//# sourceMappingURL=transcript.d.ts.map