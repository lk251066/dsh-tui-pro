/**
 * The steering queue dock: compact previews of the messages parked in the
 * agent's inbox (steered while running), plus the `/queue` management sheet
 * (edit fills the editor and replaces on submit; delete drops a message).
 * @module @deepseek-ai/dsh-tui/components/queue-dock
 */
import { type Component } from '@earendil-works/pi-tui';
import { type Palette } from './theme.ts';
/** One queue entry's render model. */
export interface QueueEntry {
    readonly id: string;
    readonly preview: string;
    /** Which inbox lane the message waits in. */
    readonly lane: 'step' | 'turn';
}
/** Compact dock listing queued messages; empty while the inbox is empty. */
export declare class QueueDockComponent implements Component {
    private readonly palette;
    private entries;
    constructor(palette: Palette);
    /** Replace the rendered entries. */
    update(entries: readonly QueueEntry[]): void;
    invalidate(): void;
    render(width: number): string[];
}
/**
 * The `/queue` management sheet: one row per queued message; Enter opens its
 * actions (edit loads it into the editor, delete drops it), Esc closes.
 */
export declare class QueueDialog implements Component {
    private readonly palette;
    private readonly onEdit;
    private readonly onDelete;
    private readonly close;
    private readonly list;
    private readonly entries;
    constructor(entries: readonly QueueEntry[], palette: Palette, onEdit: (entry: QueueEntry) => void, onDelete: (entry: QueueEntry) => void, close: () => void);
    invalidate(): void;
    handleInput(data: string): void;
    render(width: number): string[];
}
//# sourceMappingURL=queue-dock.d.ts.map