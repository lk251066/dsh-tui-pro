/**
 * The goal dock: a one-line strip above the prompt while a durable goal is
 * armed (the terminal counterpart of the web GoalBar), plus the Ctrl+G action
 * sheet (pause / resume / complete / clear).
 * @module @deepseek-ai/dsh-tui/components/goal-bar
 */
import { type Component } from '@earendil-works/pi-tui';
import { type Palette } from './theme.ts';
/** The folded-goal slice the bar renders (see `foldGoal` in dsh-goal). */
export interface GoalBarState {
    readonly objective: string;
    readonly phase: 'active' | 'paused' | 'blocked' | 'complete';
    readonly maxGoalRounds?: number;
    readonly roundsStarted?: number;
}
/** One-line goal dock rendered above the prompt; empty while no goal is armed. */
export declare class GoalBarComponent implements Component {
    private readonly palette;
    private state;
    constructor(palette: Palette);
    /** Replace the rendered goal; `undefined` hides the bar. */
    update(state: GoalBarState | undefined): void;
    invalidate(): void;
    render(width: number): string[];
}
/** One Ctrl+G action over the armed goal. */
export interface GoalAction {
    readonly id: 'pause' | 'resume' | 'complete' | 'clear';
    readonly label: string;
}
/**
 * The Ctrl+G goal action sheet: pause/resume/complete/clear for the armed
 * goal. Esc/Ctrl+C dismiss without acting.
 */
export declare class GoalActionsDialog implements Component {
    private readonly palette;
    private readonly run;
    private readonly close;
    private readonly list;
    private readonly headline;
    constructor(objective: string, actions: readonly GoalAction[], palette: Palette, run: (action: GoalAction) => void, close: () => void);
    invalidate(): void;
    handleInput(data: string): void;
    render(width: number): string[];
}
//# sourceMappingURL=goal-bar.d.ts.map