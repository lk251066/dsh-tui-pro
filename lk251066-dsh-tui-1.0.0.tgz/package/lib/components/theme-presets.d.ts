/**
 * Named color presets for `/theme`. Each preset overrides palette color roles
 * with fixed RGB values painted as 24-bit SGR on truecolor terminals, falling
 * back to a hand-picked standard-ANSI code otherwise; the `deepseek` default
 * keeps the terminal's own 16-color scheme authoritative for every adaptive
 * role, overriding only the fixed CC-derived semantic colors every preset
 * shares (permission, plan, and the reserved diff word tokens).
 * @module @deepseek-ai/dsh-tui/components/theme-presets
 */
import type { ColorRoleName } from './theme.ts';
/**
 * Keys a preset may color: the palette's live roles plus reserved tokens that
 * are defined ahead of their wiring (the diff word-level colors) and stay inert
 * until a palette role exists for them.
 */
export type PresetColorRole = ColorRoleName | 'diffAddedWord' | 'diffRemovedWord';
/** One role's preset color: exact RGB for truecolor, nearest ANSI code otherwise. */
export interface PresetColor {
    /** 24-bit foreground channels, emitted as `38;2;r;g;b` on truecolor terminals. */
    readonly rgb: readonly [number, number, number];
    /** Standard SGR color parameters for terminals without truecolor. */
    readonly ansi16: string;
    /** SGR close parameters; defaults to `39` (reset the foreground group only). */
    readonly close?: string;
    /** Attribute params composed with the truecolor foreground (the dim's faint). */
    readonly truecolorAttribute?: {
        readonly open: string;
        readonly close: string;
    };
}
/** A named theme: overrides for the palette's color roles. */
export interface ThemePreset {
    /** One-line picker description. */
    readonly description: string;
    /** Whether the palette assumes a dark terminal background. */
    readonly dark: boolean;
    /** Per-role overrides; roles absent keep the adaptive 16-color spec. */
    readonly colors: Partial<Record<PresetColorRole, PresetColor>>;
}
/**
 * The shipped themes, in picker order. `deepseek` is the adaptive default.
 */
export declare const THEME_PRESETS: Readonly<Record<string, ThemePreset>>;
/** Preset names in picker order. */
export declare const THEME_PRESET_NAMES: readonly string[];
//# sourceMappingURL=theme-presets.d.ts.map