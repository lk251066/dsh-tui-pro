/**
 * The input box chrome: the Claude Code signature rounded frame around the
 * pi-tui editor (`╭─╮ │ … │ ╰─╯`). The editor stays the TUI focus target and
 * keeps rendering its own rows (prompt prefix, fake cursor, autocomplete
 * dropdown); this wrapper only borrows those rows at `width - 4` and re-frames
 * them. The editor's zero-width hardware-cursor marker survives untouched —
 * the TUI locates it by scanning whole rendered lines and measuring the width
 * of the text before it, so the two border columns shift the reported cursor
 * column exactly with the frame.
 *
 * The editor appends its autocomplete dropdown (slash commands, `@` files)
 * after the content rows of the same render — framed naively those rows sit
 * between the side borders and inflate the box with every suggestion. This
 * component splits the dropdown rows off and emits them below the bottom
 * border, unwrapped, so the frame hugs only the input content (Claude Code
 * renders its suggestions below the box the same way).
 * @module @deepseek-ai/dsh-tui/components/framed-editor
 */
import { type Component } from '@earendil-works/pi-tui';
import type { Editor } from '@earendil-works/pi-tui';
/**
 * A rounded-corner frame around the input editor, drawn in the editor's own
 * border tone (dim while idle, accent while the agent runs — the editor
 * already switches `borderColor` on status). Pure delegation: focus, input
 * handling, and the hardware cursor all keep belonging to the wrapped editor.
 */
export declare class FramedEditorComponent implements Component {
    private readonly editor;
    constructor(editor: Editor);
    invalidate(): void;
    render(width: number): string[];
    /**
     * Pop the autocomplete dropdown's rows off the tail of `rows` so the frame
     * wraps content only; returns them ready to render below the frame.
     *
     * Recognition rule (verified against @earendil-works/pi-tui 0.80 editor.js):
     * - `Editor.render` emits content rows first, then — only while
     *   `isShowingAutocomplete()` holds — exactly `autocompleteList.render(
     *   inputWidth).length` dropdown rows, each
     *   `${leftPadding}${' '.repeat(promptWidth)}${item}…`. A trailing-count
     *   walk on row shape alone cannot work: continuation content rows carry
     *   the same all-space prefix (`prompt.continuation` is blank in our
     *   config), so with the cursor scrolled up the shape walk would swallow
     *   half the content (repro: 11-line input, cursor on line 0, `/` + Tab).
     * - So the count comes from re-rendering the live `autocompleteList` (its
     *   row count is width-invariant and the render is side-effect free) and is
     *   then validated against the known dropdown shape: every popped row opens
     *   with at least `paddingX + 1` spaces after ANSI stripping and carries
     *   neither the hardware-cursor marker nor the reverse-video fake cursor
     *   that mark the cursor content row.
     *
     * Conservative by construction: without the editor's autocomplete signal,
     * without the internals the count needs, when the count would swallow every
     * row, or when any popped row fails shape validation, the dropdown stays
     * inside the frame exactly as before.
     */
    private extractDropdownRows;
    /** Whether a rendered row has the dropdown's leading-space, cursor-free shape. */
    private looksLikeDropdownRow;
}
//# sourceMappingURL=framed-editor.d.ts.map