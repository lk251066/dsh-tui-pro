/**
 * Two-column split layout container for the assistant hub.
 * Left pane: session list; Right pane: assistant chat.
 */
import { Container, type Component } from '@earendil-works/pi-tui';
import type { Palette } from './theme.ts';
export declare class SplitLayoutComponent extends Container {
    private readonly palette;
    private leftPane;
    private rightPane;
    private leftWidth;
    private readonly minLeftWidth;
    private readonly maxLeftWidthRatio;
    constructor(palette: Palette);
    setLeftPane(component: Component): void;
    setRightPane(component: Component): void;
    render(width: number): string[];
    /** Whether the given absolute column index is in the left pane. */
    isInLeftPane(column: number): boolean;
}
//# sourceMappingURL=split-layout.d.ts.map