/**
 * The transient notice slot: a single bottom row for lightweight operation
 * receipts (state-switch feedback such as theme/model toggles, config reloads,
 * export paths) that clears itself after a timeout. Unlike transcript notices,
 * its content is presentation-only and never enters the durable conversation
 * flow; errors, warnings, and anything the user may need to scroll back to
 * still go through the persistent transcript notice path.
 * @module @deepseek-ai/dsh-tui/components/notice-slot
 */
import { type Component } from '@earendil-works/pi-tui';
import type { Palette } from './theme.ts';
/** Severity levels; colors share the transcript notice mapping. */
export type NoticeKind = 'info' | 'warning' | 'error';
/** How long a transient notice stays on screen before clearing itself. */
export declare const DEFAULT_NOTICE_DURATION_MS = 5000;
/**
 * One-row transient notice below the prompt context. At most one notice shows
 * at a time: a new `show` replaces the current row and restarts its timer.
 */
export declare class NoticeSlotComponent implements Component {
    private readonly palette;
    private readonly requestRender;
    private text;
    private kind;
    private timer;
    /**
     * @param palette - active role palette.
     * @param requestRender - invalidate hook called whenever the row appears,
     * changes, or disappears (the caller's own guard handles post-dispose calls).
     */
    constructor(palette: Palette, requestRender: () => void);
    /**
     * Show (or replace) the current notice and schedule its auto-clear.
     * @param text - message; control characters escape at this render boundary.
     * @param kind - severity, mapped to the same roles as transcript notices.
     * @param durationMs - lifetime in milliseconds before the row clears itself.
     */
    show(text: string, kind?: NoticeKind, durationMs?: number): void;
    /** Hide the current notice immediately (idempotent; cancels its timer). */
    clear(): void;
    /** Drop the pending auto-clear without rendering (teardown path). */
    dispose(): void;
    invalidate(): void;
    render(width: number): string[];
}
//# sourceMappingURL=notice-slot.d.ts.map