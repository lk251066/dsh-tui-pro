/**
 * The working status line above the input box (the Claude Code "✻ Thinking…"
 * row): a braille spinner frame, what the agent is actually doing (the newest
 * pending tool card's verb label, a per-turn whimsical verb, or `Thinking…`),
 * the elapsed wall time, and the approximate tokens streamed this turn. The
 * whole line turns warning-colored when output has stalled. Renders nothing
 * while idle.
 * @module @deepseek-ai/dsh-tui/components/working-line
 */
import { type Component } from '@earendil-works/pi-tui';
import type { Palette } from './theme.ts';
/**
 * How long without any model output before the line reads as stalled and turns
 * warning-colored. Claude Code's 3-second feel: long enough that quiet reasoning
 * bursts don't flicker, short enough to flag a hung stream quickly.
 */
export declare const STALL_WARNING_MS = 3000;
/**
 * The optional live-status extras beyond the four core inputs. All fields are
 * transient turn state: callers pass fresh values (or nothing) every tick.
 */
export interface WorkingLineStatus {
    /** This turn's whimsical spinner verb; shown only while no tool verb is pending. */
    readonly verb?: string;
    /** Approximate tokens emitted this turn; the `↓ N tokens` segment is omitted when 0/absent. */
    readonly emittedTokens?: number;
    /** Epoch-ms timestamp of the most recent model output; a gap over {@link STALL_WARNING_MS} stalls the line. */
    readonly lastOutputAt?: number;
}
/** One dim status row while the agent runs; nothing while idle. */
export declare class WorkingLineComponent implements Component {
    private readonly palette;
    private readonly now;
    private running;
    private startedAt;
    private activity;
    private frame;
    private verb;
    private emittedTokens;
    private lastOutputAt;
    constructor(palette: Palette, now: () => number);
    /**
     * Drive the whole line in one call (each spinner tick).
     * @param running - Whether the agent is mid-turn.
     * @param startedAt - Turn start in epoch ms (clamps elapsed at 0 until set).
     * @param activity - Newest pending tool verb label; `undefined` = no tool in flight.
     * @param frame - Braille spinner frame, or `undefined` before the first tick.
     * @param status - Optional extras: turn verb, streamed-token count, last-output
     * timestamp. Omitted (or an omitted field) drops that segment/behavior.
     */
    update(running: boolean, startedAt: number | undefined, activity: string | undefined, frame: string | undefined, status?: WorkingLineStatus): void;
    invalidate(): void;
    render(width: number): string[];
}
//# sourceMappingURL=working-line.d.ts.map