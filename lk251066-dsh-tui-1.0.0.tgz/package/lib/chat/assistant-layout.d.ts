/**
 * Assistant hub split-view layout: left pane shows session list, right pane
 * shows assistant chat. Only active when the assistant session is mounted.
 * @module @deepseek-ai/dsh-tui/chat/assistant-layout
 */
import { SessionListComponent } from '../components/session-list.ts';
import { SplitLayoutComponent } from '../components/split-layout.ts';
import type { Palette } from '../components/theme.ts';
import type { ChannelRegistry } from './channel-registry.ts';
import type { TuiSessionSlot } from '../index.ts';
export interface AssistantLayoutController {
    /** The split-view container (replaces single chat in UI tree). */
    readonly splitLayout: SplitLayoutComponent;
    /** The left pane session list component. */
    readonly sessionList: SessionListComponent;
    /** Refresh the session list from current registry state. */
    refresh(): void;
    /** Navigate list: select next session (down arrow). */
    selectNext(): void;
    /** Navigate list: select previous session (up arrow). */
    selectPrevious(): void;
    /** Switch to the currently selected session in the list. */
    switchToSelected(): void;
    /** Whether the split-view is currently active (assistant mounted). */
    isActive(): boolean;
}
export interface AssistantLayoutDeps {
    readonly palette: Palette;
    readonly registry: ChannelRegistry<TuiSessionSlot>;
    /** Terminal height for list sizing. */
    terminalRows: () => number;
    /** Request full UI repaint. */
    requestRender(): void;
}
/**
 * Create the assistant hub's split-view layout controller. The layout is only
 * active when the assistant session is mounted; other sessions use the
 * traditional full-width chat.
 */
export declare function createAssistantLayout(deps: AssistantLayoutDeps): AssistantLayoutController;
//# sourceMappingURL=assistant-layout.d.ts.map