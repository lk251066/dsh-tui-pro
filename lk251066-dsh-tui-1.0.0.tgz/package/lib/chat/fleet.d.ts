/**
 * The `/fleet` board: every persisted session in the store as one read-only
 * monitor row — title, workspace, last activity, and a live marker for
 * sessions that moved recently (the "probably running somewhere" signal).
 * This is the personal workstation's cross-process view: it scans the
 * durable store, so it sees sessions owned by OTHER dsh processes too.
 * @module @deepseek-ai/dsh-tui/chat/fleet
 */
import type { InsightsDeps } from './insights.ts';
/** A session counts as active when its last change is younger than this. */
export declare const FLEET_ACTIVE_MS: number;
/** Rows shown before this many sessions; the tail folds into a count note. */
export declare const FLEET_MAX_ROWS = 20;
/**
 * The board's rows: header with counts, then one row per session — an active
 * marker (●) or idle dot (·), the title (or id when untitled), the age of the
 * last change, and the workspace label. Most recent first; the tail beyond
 * {@link FLEET_MAX_ROWS} folds into one dim count note.
 * @param deps - channel collaborators (context and terminal cwd formatting).
 * @param signal - optional cancellation for the store scan.
 * @returns the rendered rows.
 */
export declare function fleetLines(deps: InsightsDeps, signal?: AbortSignal): Promise<string[]>;
//# sourceMappingURL=fleet.d.ts.map