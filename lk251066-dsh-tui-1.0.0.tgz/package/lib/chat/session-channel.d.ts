/**
 * Per-session chat channel: the transcript container and every piece of
 * presentation state that belongs to exactly one agent's session (streaming
 * components, tool/context cards, turn status, token totals, steering
 * bookkeeping), plus the event listeners that keep them current. `index.ts`
 * owns the shared chrome (TUI, editor, palette, header, docks) and mounts one
 * channel per driven session; the multi-session work ahead swaps the mounted
 * channel under the same chrome.
 *
 * This module is a byte-for-byte behavior-preserving extraction of the
 * per-agent closures that previously lived inside `createTuiChat`; nothing
 * here reorders, rewrites, or re-times the moved logic.
 * @module @deepseek-ai/dsh-tui/chat/session-channel
 */
import { Container, type MarkdownTheme } from '@earendil-works/pi-tui';
import type { Context } from '@deepseek-ai/cordis';
import type { Agent, AgentStatus } from '@deepseek-ai/dsh-agent';
import type { MessageId } from '@deepseek-ai/dsh-llm';
import { type SessionEvent } from '@deepseek-ai/dsh-session';
import { type SessionTokenTotals } from './tokens.ts';
import type { ResolvedTuiConfig } from '../config.ts';
import { type ToolCardVisibility, StreamingAssistantComponent, TodoComponent } from '../components/transcript.ts';
import type { Palette } from '../components/theme.ts';
import type { TuiTerminalLike } from './terminal.ts';
/**
 * The shared chrome and services one session channel needs from its host.
 * Large by design: the channel is the extracted half of `createTuiChat`, so
 * this interface is exactly the half that stayed behind.
 */
export interface SessionChannelDeps {
    readonly ctx: Context;
    /** The agent whose session this channel renders. */
    readonly agent: Agent;
    /** Resolved presentation config (line limits, tool-card sizing). */
    readonly resolved: ResolvedTuiConfig;
    /** Shared palette; the host may swap its roles in place. */
    readonly palette: Palette;
    /** Shared markdown theme; the host may swap its callbacks in place. */
    readonly mdTheme: MarkdownTheme;
    /** Logical render clock; the host's `runtime.now`. */
    now(): number;
    /** Terminal façade for the progress bit; the host's `runtime.terminal`. */
    readonly terminal: TuiTerminalLike;
    /** Redraw the channel (also refreshes prompt values and chrome). */
    requestRender(): void;
    /** Append a durable notice row to the transcript. */
    appendNotice(message: string, kind?: 'info' | 'warning' | 'error'): void;
    /** Resolve one stored image attachment's bytes (optional store). */
    loadAttachmentImage(attachmentId: string): Promise<Uint8Array | undefined>;
    /** Learn a rendered prompt into the shared editor's history. */
    addToEditorHistory(text: string): void;
    /** The goal dock refreshes on goal/turn events (host-owned chrome). */
    refreshGoalBar(): void;
    /** The queue dock refreshes on inbox-affecting events (host-owned chrome). */
    refreshQueueDock(): void;
    /** The title/header/terminal-title chrome refresh on `session/title`. */
    onSessionTitle(title: string): void;
    /** File-search cache invalidation hook (`tool/result`). */
    onToolResult(): void;
    /**
     * Apply an agent-status edge in full (channel state machine plus the host's
     * editor border/hint/working-line chrome); the channel's own event listeners
     * call this so the host side runs exactly as a direct `setStatus` would.
     */
    applyStatus(status: AgentStatus): void;
    /** Whether the transcript renders reasoning blocks. */
    showReasoning(): boolean;
    /** Current tool-card visibility phase. */
    toolsVisibility(): ToolCardVisibility;
    /**
     * Spinner tick with work in flight: drive the host-owned working line with
     * the frame, the active status origin, the pending call's label, and the
     * streamed-token/stall extras, then redraw.
     */
    onSpinnerFrame(running: boolean, startedAt: number | undefined, label: string | undefined, frame: string, extras: {
        verb: string;
        emittedTokens: number;
        lastOutputAt?: number;
    }): void;
    /** Spinner tick with nothing in flight: hide the working line and redraw. */
    onSpinnerIdle(): void;
    /**
     * Agent-level error observed on the event stream: the host retains it for
     * its live-error set and appends the durable notice.
     */
    onAgentError(stepKey: string, error: unknown): void;
    /** The channel's agent left the registry; the host marks itself disposed. */
    onAgentDisposed(): void;
}
/** One session's chat channel as seen by its host chrome. */
export interface SessionChannel {
    /** Transcript container the host mounts once in its chrome. */
    readonly chat: Container;
    /** Todo strip component (mounted by the host inside `todoContainer`). */
    readonly todo: TodoComponent;
    /** Live token totals for the prompt footer and diagnostics. */
    tokens(): SessionTokenTotals;
    /** Whether a turn is currently running (spinner/working-line input). */
    isRunning(): boolean;
    /** Whether a standalone compaction is live (working-line input). */
    isCompacting(): boolean;
    /** Render clock of the running turn's start (working-line input). */
    runningStartedAt(): number | undefined;
    /** Render clock of the live standalone compaction's start, when one runs. */
    compactingStartedAt(): number | undefined;
    /** The live phase glyph the fade-out should show; feeds the running seed. */
    noteRenderedStatusGlyph(glyph: string | undefined): void;
    /**
     * Fade envelope for the prompt caret: the running/compaction fade-in when a
     * glyph is active, else the running fade-out, else `undefined`.
     */
    statusGlyphEnvelope(glyph: string | undefined, renderTime: number): {
        glyph: string;
        level: number;
    } | undefined;
    /** Re-apply the current visibility phase to cards, groups, and context cards. */
    applyToolsVisibility(visibility: ToolCardVisibility): void;
    /** Turns that currently carry registered assistant steps. */
    assistantStepTurns(): Iterable<number>;
    /** Detach the live streaming component (preserved across a rebuild). */
    detachStreaming(): StreamingAssistantComponent | undefined;
    /** Steering submissions not yet claimed or discarded (prompt badge). */
    pendingSteeringCount(): number;
    /**
     * The process-wide spinner tick body: animate the newest pending card and
     * derive the working-line frame. The host owns the interval so teardown
     * stays single-owner; it calls this each tick.
     */
    readonly tickSpinner: (frame: string) => void;
    /** Register the channel's session-scoped `ctx` listeners. */
    attach(): void;
    /** Unregister the listeners `attach` registered. */
    detach(): void;
    /** Render one session event into the transcript. */
    renderEvent(event: SessionEvent, options: {
        addHistory: boolean;
        renderChunks: boolean;
    }): void;
    /** Re-derive the whole transcript from the session log. */
    rebuildTranscript(populateHistory: boolean): void;
    /**
     * The channel half of the status state machine (running/fading glyphs,
     * progress bit); the host's `setStatus` wraps it with editor chrome.
     */
    setStatus(status: AgentStatus): void;
    /** Invalidate the live streaming component and redraw (steering badge edges). */
    refreshStatus(): void;
    /** Drop every status indicator, including a live compaction bracket. */
    clearStatus(): void;
    /** Re-derive hidden-mode folding for one turn's assistant steps. */
    applyTurnFolding(turn: number): void;
    /** Whether the session log carries at least one compaction checkpoint. */
    hasCompactionCheckpoint(): boolean;
    /** Track a steering submission until it is claimed or discarded. */
    addPendingSteering(id: MessageId): void;
    /** Label of the tool card a pending approval asks about. */
    toolCardLabel(callId: string | undefined): string | undefined;
    /**
     * Preserve an active stream across a host transcript rebuild: re-attach the
     * (already detached) streaming component.
     */
    restoreStreaming(component: StreamingAssistantComponent): void;
}
/**
 * Build one session's chat channel.
 * @param deps - the host chrome callbacks and shared services listed above.
 * @returns the channel handle.
 */
export declare function createSessionChannel(deps: SessionChannelDeps): SessionChannel;
//# sourceMappingURL=session-channel.d.ts.map