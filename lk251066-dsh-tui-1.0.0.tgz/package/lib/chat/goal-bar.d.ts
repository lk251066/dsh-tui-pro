/**
 * Goal-dock controller: derives the bar state from the session log via
 * `foldGoal`, refreshes on goal events, and runs Ctrl+G actions through the
 * optional `ctx.goals` service.
 * @module @deepseek-ai/dsh-tui/chat/goal-bar
 */
import type { Agent } from '@deepseek-ai/dsh-agent';
import { GoalBarComponent } from '../components/goal-bar.ts';
import type { ChannelNotice, ChatChannelDeps } from './channel.ts';
/** Collaborators the goal dock needs from the chat channel. */
export interface GoalBarDeps extends ChatChannelDeps, ChannelNotice {
    /** The agent whose armed goal the bar shows. */
    agent: Agent;
}
/** Goal-dock controller for one chat channel. */
export interface GoalBarController {
    /** The mounted bar component (already parented by the caller). */
    readonly component: GoalBarComponent;
    /** Re-derive from the session log (call on every session event). */
    refresh(): void;
    /** Open the Ctrl+G action sheet over the armed goal. */
    showActions(): void;
    /** Tear down listeners. */
    dispose(): void;
}
/**
 * Build the goal dock for one chat channel.
 * @param deps - channel collaborators and the owned agent.
 * @returns the controller; `component` renders nothing until a goal is armed.
 */
export declare function createGoalBar(deps: GoalBarDeps): GoalBarController;
//# sourceMappingURL=goal-bar.d.ts.map