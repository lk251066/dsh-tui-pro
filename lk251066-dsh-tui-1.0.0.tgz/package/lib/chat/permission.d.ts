/**
 * Shift+Tab permission-preset cycling, the Claude Code mode ring adapted to
 * dsh's preset table: read-only → workspace-write → danger-full-access (the
 * shipped order). Selecting the danger preset confirms first, mirroring the
 * web surface's risk acknowledgement.
 * @module @deepseek-ai/dsh-tui/chat/permission
 */
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { ChannelNotice, ChatChannelDeps } from './channel.ts';
/** The permission-presets service surface the TUI reads (optional at runtime). */
export interface PermissionPresetsService {
    readonly names: readonly string[];
    current(events: readonly unknown[]): string;
    resolve(name: string): {
        sandbox: string;
        approval?: string;
        description?: string;
    };
    set(session: unknown, name: string): unknown;
}
/** Collaborators the permission ring needs from the chat channel. */
export interface PermissionDeps extends ChatChannelDeps, ChannelNotice {
    /** The agent whose session's preset cycles. */
    agent: Agent;
    /**
     * Open the danger-preset confirmation overlay. A `\n`-separated message
     * renders its first line as an error-colored warning title.
     */
    confirmRisk(message: string, onChoice: (confirmed: boolean) => void): void;
}
/** Permission-ring controller for one chat channel. */
export interface PermissionController {
    /** Shift+Tab: switch to the next preset (confirming the danger one). */
    cycle(): void;
    /** The effective preset name for the prompt chip, when presets are mounted. */
    chip(): string | undefined;
}
/**
 * Build the Shift+Tab permission ring for one chat channel.
 * @param deps - channel collaborators and the risk-confirmation host.
 * @returns the controller wired into the input listener and prompt values.
 */
export declare function createPermissionController(deps: PermissionDeps): PermissionController;
//# sourceMappingURL=permission.d.ts.map