/**
 * Assistant-specific tools for session monitoring and coordination.
 * These tools are installed only in the assistant agent's scope.
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ChannelRegistry } from './channel-registry.ts';
import type { TuiSessionSlot } from '../index.ts';
export declare function installAssistantTools(agentCtx: Context, registry: ChannelRegistry<TuiSessionSlot>): void;
//# sourceMappingURL=assistant-tools.d.ts.map