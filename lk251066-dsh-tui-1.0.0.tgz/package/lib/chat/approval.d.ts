/**
 * Tool-approval sub-machine for the interactive chat channel. Claims the
 * `approval/request` waterfall for THIS channel's agent and answers it with a
 * keyboard overlay — the terminal counterpart of the web ApprovalPanel, and the
 * difference between a tool call that runs and one that fails closed with
 * "no approval channel available".
 *
 * Every claimed request resolves on ALL paths (choice, Esc, abort, overlay
 * error, shutdown): a hung overlay would hang the tool call behind it. Requests
 * for other agents (subagents) fall through to `next()` unchanged.
 * @module @deepseek-ai/dsh-tui/chat/approval
 */
import type { Agent } from '@deepseek-ai/dsh-agent';
import { type CallId } from '@deepseek-ai/dsh-llm';
import type { ChannelNotice, ChatChannelDeps } from './channel.ts';
/** Collaborators the approval answerer needs from the chat channel. */
export interface ApprovalAnswererDeps extends ChatChannelDeps, ChannelNotice {
    /** The one agent whose asks this terminal answers. */
    agent: Agent;
    /** Current row budget after reserving the editor. */
    questionMaxHeight(): number;
    /** The pending tool call's one-line label, when its card is on screen. */
    pendingCallLabel(callId: CallId | undefined): string | undefined;
}
/** Tool-approval controller for one chat channel. */
export interface ApprovalAnswerer {
    /** Settle the active and all queued asks `'cancelled'` (shutdown). */
    drain(): void;
    /** Remove the waterfall listener. */
    unregister(): void;
}
/**
 * Build the approval answerer for one chat channel.
 * @param deps - channel collaborators, the owned agent, and the overlay host.
 * @returns the controller used at shutdown to drain and unregister.
 */
export declare function createApprovalAnswerer(deps: ApprovalAnswererDeps): ApprovalAnswerer;
//# sourceMappingURL=approval.d.ts.map