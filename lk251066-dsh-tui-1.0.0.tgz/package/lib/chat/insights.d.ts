/**
 * Insight surfaces for the terminal: the `/context` occupancy breakdown, the
 * prompt-row stats strip, the `/agents` and `/jobs` monitors, `/settings`, and
 * the `/export` markdown transcript. All read optional services (`ctx.get`) so
 * the TUI mounts in embedder bundles without them.
 * @module @deepseek-ai/dsh-tui/chat/insights
 */
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { Session } from '@deepseek-ai/dsh-session';
import type { Palette } from '../components/theme.ts';
import type { ChannelNotice, ChatChannelDeps } from './channel.ts';
/** Collaborators the insight surfaces need from the chat channel. */
export interface InsightsDeps extends ChatChannelDeps, ChannelNotice {
    /** The agent whose session every surface reads. */
    agent: Agent;
}
/**
 * One compact stats-strip value for the LEFT prompt row (the right prompt
 * crowds out the left when both are wide, so the strip lives after the context
 * bar and is the first thing a narrow terminal truncates). `undefined` without
 * the sessionStats projection.
 */
export declare function statsStrip(deps: InsightsDeps): string | undefined;
/** Cell counts for the four segments of the `/context` composition bar. */
export interface SegmentCells {
    readonly system: number;
    readonly tools: number;
    readonly messages: number;
    readonly free: number;
}
/**
 * Allocate the `/context` composition bar's cells, Claude Code's single
 * multi-color bar: the window is the whole bar, the used part covers
 * `round(system + tools + messages / window · width)` cells split across the
 * three categories by largest remainder, and the unused remainder is free
 * space. A composition exceeding the window clamps to a full bar with no free
 * cells.
 *
 * @param parts - The three category token counts from `contextBreakdown`.
 * @param windowTokens - The context window; `<= 0` yields an all-free bar.
 * @param width - Total bar width in cells; defaults to {@link SEGMENT_BAR_WIDTH}.
 * @returns The per-segment cell counts; the four always sum to `width`.
 */
export declare function contextSegmentCells(parts: {
    system: number;
    tools: number;
    messages: number;
}, windowTokens: number, width?: number): SegmentCells;
/** The `/context` body rows: occupancy header, pressure meters, composition bar and legend. */
export declare function contextLines(deps: InsightsDeps, palette: Palette): string[];
export declare function agentsLines(deps: InsightsDeps, signal: AbortSignal): Promise<string[]>;
/** The `/jobs` body rows over the job registry, filtered to this session. */
export declare function jobsLines(deps: InsightsDeps): string[];
/** The `/settings` body rows over the settings registry (secrets redacted). */
export declare function settingsLines(deps: InsightsDeps): string[];
/** Render the whole session log as a markdown transcript. */
export declare function exportMarkdown(session: Session): string;
/** Write the transcript atomically (temp file + rename) and return the path. */
export declare function writeExport(cwd: string, session: Session): string;
/** Open one static insight overlay. */
export declare function openStaticDialog(deps: InsightsDeps, title: string, lines: readonly string[], refresh?: () => readonly string[]): void;
//# sourceMappingURL=insights.d.ts.map