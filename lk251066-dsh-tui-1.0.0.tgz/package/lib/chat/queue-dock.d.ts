/**
 * Queue-dock controller: mirrors the agent's inbox lanes into the dock, drives
 * the `/queue` sheet, and carries the edit-in-flight target so a submitted
 * edit REPLACES its queued message instead of enqueuing a new one.
 * @module @deepseek-ai/dsh-tui/chat/queue-dock
 */
import type { Agent } from '@deepseek-ai/dsh-agent';
import { type ContentBlock, type UserMessage } from '@deepseek-ai/dsh-llm';
import { QueueDockComponent } from '../components/queue-dock.ts';
import type { ChannelNotice, ChatChannelDeps } from './channel.ts';
/** Collaborators the queue dock needs from the chat channel. */
export interface QueueDockDeps extends ChatChannelDeps, ChannelNotice {
    /** The agent whose inbox the dock mirrors. */
    agent: Agent;
    /** Load a message body into the editor for editing (the caller owns the editor). */
    loadIntoEditor(text: string): void;
    /**
     * Show an operation receipt in the transient notice slot; absent falls back
     * to the persistent transcript notice.
     */
    showTransientNotice?(message: string): void;
}
/** Queue-dock controller for one chat channel. */
export interface QueueDockController {
    /** The mounted dock component (already parented by the caller). */
    readonly component: QueueDockComponent;
    /** Re-derive from the inbox (call on inbox events). */
    refresh(): void;
    /** Open the `/queue` management sheet. */
    showSheet(): void;
    /** How many messages currently wait in the inbox lanes. */
    pendingCount(): number;
    /**
     * Pop the newest queued message back into the editor for editing (empty-input
     * ↑): arms the same submit-replaces-queued-message target the sheet's edit
     * path uses. The message stays queued until the edit is submitted.
     * @returns whether a queued message was armed and loaded.
     */
    armLatestForEdit(): boolean;
    /**
     * A pending edit target: when set, the next submit replaces this queued
     * message rather than dispatching a new turn; cleared after one submit.
     */
    takeEditTarget(): UserMessage | undefined;
    /** Whether an inbox edit is armed (suppresses the ordinary submit path). */
    hasEditTarget(): boolean;
    /** Tear down state. */
    dispose(): void;
}
/**
 * Build the queue dock for one chat channel.
 * @param deps - channel collaborators, the owned agent, and the editor loader.
 * @returns the controller.
 */
export declare function createQueueDock(deps: QueueDockDeps): QueueDockController;
/** Build the replacement for an edited queued message: fresh identity, same source. */
export declare function replaceQueuedMessage(message: UserMessage, content: readonly ContentBlock[]): UserMessage;
//# sourceMappingURL=queue-dock.d.ts.map