/**
 * The personal-assistant session (R2-3): a fixed-id live session under the
 * shared chrome with its own persona and, when the memory plugin is mounted,
 * the assistant-scoped memory tools and recalled-memories prompt section. The
 * session persists like any other: the next process resumes the same
 * conversation, and `setup` re-installs the persona either way.
 * @module @deepseek-ai/dsh-tui/chat/assistant
 */
import type { Context } from '@deepseek-ai/cordis';
import { SessionId } from '@deepseek-ai/dsh-session';
import type { TuiSessionSlot } from '../index.ts';
import type { ChannelRegistry } from './channel-registry.ts';
/** The assistant's fixed session id — stable across processes by design. */
export declare const ASSISTANT_SESSION_ID: SessionId;
/**
 * The assistant's persona, shadowing the deployment persona for this one
 * session (the same-section replacement the system-prompt registry defines).
 * Plain text: the strict `{{variable}}` interpolation rejects unknown names.
 */
export declare const ASSISTANT_PERSONA: string;
/**
 * Install the assistant's scoped world on one (unpublished) agent context: the
 * persona shadow plus, when the memory service is mounted, its tools and the
 * auto-recalled memories section, plus the assistant-specific session control tools.
 * @param agentCtx - the agent scope `setup` receives.
 * @param registry - the multi-session registry for session control tools.
 */
export declare function setupAssistant(agentCtx: Context, registry: ChannelRegistry<TuiSessionSlot>): void;
/** Collaborators the assistant controller needs from the host chrome. */
export interface AssistantControllerDeps {
    readonly ctx: Context;
    /** The multi-session registry the assistant slot adopts into. */
    readonly registry: ChannelRegistry<TuiSessionSlot>;
    /** Workspace recorded on a freshly created assistant session. */
    readonly cwd: string;
    /** Durable transcript notice. */
    appendNotice(message: string, kind?: 'info' | 'warning' | 'error'): void;
    /** Transient operation receipt. */
    showTransientNotice(message: string): void;
    /** Whether the TUI is gone (async continuation guard). */
    isDisposed(): boolean;
}
/**
 * Open-or-switch the assistant session. Three fast-to-slow branches: a live
 * registry slot switches; a live-but-evicted agent re-adopts; otherwise the
 * persisted log resumes (this process or an earlier one) or the session is
 * created fresh — `setup` rides either path.
 * @param deps - channel collaborators and the registry.
 * @returns the controller wired to the `/assistant` command.
 */
export declare function createAssistantController(deps: AssistantControllerDeps): {
    open(): void;
};
//# sourceMappingURL=assistant.d.ts.map