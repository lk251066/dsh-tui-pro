/**
 * The `/memories` browser: the durable memory store rendered as rows for the
 * keyboard browser dialog. Pure formatting — the command handler reads the
 * optional `ctx.memory` service and degrades to a notice when absent.
 * @module @deepseek-ai/dsh-tui/chat/memories
 */
import type { MemoryRecord } from '@deepseek-ai/dsh-memory';
import type { MemoryRowView } from '../components/dialogs.ts';
/** Rows shown when the memory plugin is not mounted in this composition. */
export declare const MEMORY_UNAVAILABLE_LINES: string[];
/**
 * Map the store's records to browser rows: the label is the full text (the
 * dialog truncates to width), the detail carries tags and the updated date.
 * @param records - the store's current records.
 * @returns the browser rows in first-creation order.
 */
export declare function memoryRows(records: readonly MemoryRecord[]): MemoryRowView[];
//# sourceMappingURL=memories.d.ts.map