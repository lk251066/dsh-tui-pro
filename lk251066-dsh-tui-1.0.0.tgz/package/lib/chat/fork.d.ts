/**
 * Session fork: branch the conversation at a completed-turn boundary into a
 * fresh session (the terminal counterpart of the web per-message Branch
 * action). The boundary algorithm mirrors the web host's fork: the last
 * `turn/end` at-or-before the anchor, extended through trailing out-of-band
 * events until the next `turn/start`.
 * @module @deepseek-ai/dsh-tui/chat/fork
 */
import type { Agent } from '@deepseek-ai/dsh-agent';
import { SessionId, type SessionEvent } from '@deepseek-ai/dsh-session';
import type { ChannelNotice, ChatChannelDeps } from './channel.ts';
/**
 * The seed boundary for a fork: the event index ONE PAST the last `turn/end`
 * at or before `atSeq` (or the last `turn/end` overall), extended through any
 * trailing out-of-band events (approval audit pairs, titles) until the next
 * `turn/start`.
 * @param events - The session log in order.
 * @param atSeq - Optional event-seq anchor (fork at this message's turn);
 * the log's last completed turn when omitted.
 * @returns The exclusive cut index, or `undefined` when no completed turn exists.
 */
export declare function forkCut(events: readonly SessionEvent[], atSeq?: number): number | undefined;
/** Collaborators the fork command needs from the chat channel. */
export interface ForkDeps extends ChatChannelDeps, ChannelNotice {
    /** The agent whose session forks. */
    agent: Agent;
    /** Hand off into the forked session when a resume host is mounted. */
    handoffResume?: (sessionId: SessionId, cwd: string) => void;
}
/**
 * Fork the agent's session at its last completed turn (or fail with a notice),
 * then hand off into the child when the runtime supports it.
 * @param deps - channel collaborators and the resume-handoff boundary.
 */
export declare function forkSession(deps: ForkDeps): Promise<void>;
//# sourceMappingURL=fork.d.ts.map