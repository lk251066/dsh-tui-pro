/**
 * Claude-Code-style card titles: a present-progressive verb phrase while a
 * call runs (`⠋ Reading src/foo.ts`) and a settled label with its duration
 * (`⏺ Read src/foo.ts · 0.4s`). Derived purely from the tool-presented views
 * the transcript already computes, so every tool gets a readable header
 * without per-tool special cases here.
 * @module @deepseek-ai/dsh-tui/chat/tool-verbs
 */
/**
 * The title-bearing slice of call and result views the verb functions read:
 * a card tag plus the presenter's (possibly result-replaced) title.
 */
export interface VerbView {
    card: string;
    title?: string;
    description?: string;
}
/**
 * Rewrite a view title's leading verb into its progressive form
 * (`Read src/foo.ts` → `Reading src/foo.ts`); unknown leading words pass through.
 */
export declare function progressiveTitle(name: string, view: VerbView): string;
/**
 * The settled-state label: the presenter's own title (terminal cards headline
 * the description or the command, Claude-Code `Bash(git status)` style).
 */
export declare function settledTitle(name: string, view: VerbView): string;
//# sourceMappingURL=tool-verbs.d.ts.map