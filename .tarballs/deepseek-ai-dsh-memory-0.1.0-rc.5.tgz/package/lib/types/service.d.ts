/**
 * Durable long-term memory about the user. One storage-domain sidecar every
 * surface shares: the personal assistant's scoped `memory_save`/`memory_search`
 * tools, its auto-recalled prompt section, and the TUI's `/memories` browser
 * all read and write this one store.
 *
 * Memory is process-independent by design: rows live in the storage-domain
 * `memory` domain (the host's `storages` root), so facts survive restarts and
 * outlive any single conversation.
 * @module @deepseek-ai/dsh-memory/service
 */
import { Context, Service } from '@deepseek-ai/cordis';
import s from '@deepseek-ai/schemastery';
import type { Config, MemoryId, MemoryRecord } from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        memory: MemoryService;
    }
}
/** Default prompt-section budget when config omits `recallMaxChars`. */
export declare const DEFAULT_RECALL_MAX_CHARS = 4000;
/** Default per-memory text budget when config omits `maxTextBytes`. */
export declare const DEFAULT_MAX_TEXT_BYTES = 2000;
/** Default store-size ceiling when config omits `maxMemories`. */
export declare const DEFAULT_MAX_MEMORIES = 200;
/** Default result ceiling for `memory_search` when the caller omits `limit`. */
export declare const DEFAULT_SEARCH_LIMIT = 20;
/**
 * Long-term memory service: one durable domain, synchronous reads, write-chain
 * durability, and the assistant-scoped tool/section installation.
 */
export default class MemoryService extends Service {
    static inject: string[];
    static Config: s<Config>;
    private table;
    private readonly maxTextBytes;
    private readonly recallMaxChars;
    private readonly maxMemories;
    /**
     * @param ctx - Host context carrying the storage-domain form.
     * @param config - Deployment-varying text, recall, and store-size budgets.
     */
    constructor(ctx: Context, config: Config);
    /** Open and own the one memory domain. */
    protected [Service.init](): Promise<void>;
    /** All memories in first-creation order. */
    list(): readonly MemoryRecord[];
    /**
     * Save one durable memory. Text is trimmed and validated; tags normalize.
     * @returns the stored record.
     */
    add(text: string, tags?: readonly string[]): Promise<MemoryRecord>;
    /**
     * Drop the oldest-created memories until the store fits its ceiling. An
     * over-ceiling store (a lowered config over old data) trims on the next
     * `add`, which is the only mutation path that can grow the store.
     */
    private evictToCeiling;
    /**
     * Replace one memory's text and/or tags.
     * @returns the updated record, or `undefined` when the id is unknown.
     */
    update(id: MemoryId, patch: {
        text?: string;
        tags?: readonly string[];
    }): Promise<MemoryRecord | undefined>;
    /**
     * Remove one memory.
     * @returns whether a memory with that id existed.
     */
    remove(id: MemoryId): Promise<boolean>;
    /**
     * Keyword search across text and tags, case-insensitive substring.
     * @returns matches most-recently-updated first, at most `limit` (default 20).
     */
    search(query: string, limit?: number): readonly MemoryRecord[];
    /**
     * The auto-recalled prompt section's text: every memory, most recent first,
     * truncated to a character budget. A store that is uninitialized, closed, or
     * empty renders nothing — a prompt section must never break assembly.
     */
    recalledText(budgetChars?: number): string;
    /**
     * Install the memory tools and prompt sections on ONE agent's scope: the
     * registrations live under that agent's context, so only agents set up this
     * way (the personal assistant) see them.
     */
    installTools(agentCtx: Context): void;
    /** Trim and validate one memory text against the configured byte budget. */
    private validateText;
    /** Resolve the initialized durable table or fail a broken service lifecycle. */
    private requireTable;
}
//# sourceMappingURL=service.d.ts.map