/**
 * Durable storage-domain declaration for long-term user memory.
 * @module @deepseek-ai/dsh-memory/src/spec
 */
import { z } from 'zod';
import type { MemoryId, MemoryVersion } from './types.ts';
/** Runtime schema for one opaque row version stored on disk. */
export declare const memoryVersionSchema: z.ZodPipe<z.ZodUUID, z.ZodTransform<MemoryVersion, string>>;
/** One normalized lookup tag: non-empty, trimmed, lowercase. */
export declare const memoryTagSchema: z.ZodString;
/** Runtime schema for one durable memory row. */
export declare const memoryRowSchema: z.ZodType<MemoryRow>;
/** Persisted row shape inferred from the durable schema's output. */
export interface MemoryRow {
    /** One short, self-contained fact or preference, stored trimmed. */
    readonly text: string;
    /** Normalized lookup tags. */
    readonly tags: readonly string[];
    readonly createdAt: number;
    readonly updatedAt: number;
    readonly version: MemoryVersion;
}
/** One durable memory row per id. */
export declare const memoryDomainSpec: {
    name: string;
    version: number;
    tables: {
        memories: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<MemoryId, MemoryRow>;
    };
};
//# sourceMappingURL=spec.d.ts.map